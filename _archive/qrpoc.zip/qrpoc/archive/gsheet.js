const { GoogleSpreadsheet } = require('google-spreadsheet');
const SPREADSHEET_ID = "1CdgNCnfOYKKW-hbeUtv_biIuWPrWXAQCzc0xhRS3wUQ";
const GOOGLE_API_KEY = "AIzaSyBzv_xPK2FupPbF2OFKsgQRJ8LttmZGG7k";

class SheetsController { 

    async addRowToSheet(data) {
    const doc = new GoogleSpreadsheet(SPREADSHEET_ID, { apiKey: process.env.GOOGLE_API_KEY });

    try {
        await doc.loadInfo(); // Loads document properties and worksheets
        const sheet = doc.sheetsByIndex[0]; // or use doc.sheetsById[id] or doc.sheetsByTitle[title]

        // Add a row to the sheet with the provided object data
        const addedRow = await sheet.addRow(data);
        console.log(`Added row: ${JSON.stringify(addedRow)}`);
    } catch (error) {
        console.error('Error adding row to Google Sheet:', error);
    }
    }
}


module.exports = SheetsController;